# 报告配图输入说明

这些文件只定义数据格式，不包含虚构实验值。将对应 `.example.*` 复制为无
`.example` 的文件名并填入真实结果，再运行章节脚本。

## 第三部分

- `e2_results.csv`：`name,conv_depth,hidden_dim,parameters,accuracy`
- `e4_history.csv`：`step,strategy,val_accuracy`，同一策略写多行
- `seed_results.csv`：`seed,method,accuracy`，配对方法必须使用相同种子
- `error_categories.csv`：`category,count`
- `case_quads.json`：每个案例依次提供原图、检测裁剪、矫正图和结果图路径
- E1 直接读取 `outputs/ablation_e1.json`，由 `scripts/run_ablation.py` 生成

## 第四部分

- `milestones.csv`：`task,start,end,completion`，日期为 `YYYY-MM-DD`
- `overfit_history.json`：直接保存训练命令输出中的 `history`
- `stn_geometry_check.json`：保存四个 STN 几何自检案例；字段见示例文件

## 第五部分

- `perspective_failures.json`：真实分母无效率、越界率、回退率和最多四张案例图
- `problem_priorities.csv`：`impact` 与 `urgency` 均使用 1-5，`priority` 使用 P0/P1/P2

准确率、比例字段既可写 `0.812`，也可写 `81.2`；脚本会自动识别。

